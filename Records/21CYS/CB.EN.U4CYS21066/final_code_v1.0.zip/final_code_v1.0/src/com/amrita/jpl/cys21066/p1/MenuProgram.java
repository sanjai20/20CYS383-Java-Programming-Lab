package com.amrita.jpl.cys21066.p1;

import java.util.Scanner;

public class MenuProgram {
    public static int factorial(int n) {
        if (n < 0) {
            System.out.println("Error: Factorial not defined for negative numbers.");
            return -1;
        }

        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }

    public static void fibonacci(int n) {
        if (n < 0) {
            System.out.println("Error: Fibonacci sequence not defined for negative numbers.");
            return;
        }

        int first = 0;
        int second = 1;
        System.out.print("Fibonacci sequence: ");
        for (int i = 0; i < n; i++) {
            System.out.print(first + " ");
            int next = first + second;
            first = second;
            second = next;
        }
        System.out.println();
    }

    public static int sumOfNumbers(int n) {
        if (n < 0) {
            System.out.println("Error: Sum of numbers not defined for negative numbers.");
            return -1;
        }

        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    public static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int choice = scanner.nextInt();

        System.out.println("1. Factorial (fact)");
        System.out.println("2. Fibonacci (fibo)");
        System.out.println("3. The sum of 'n' numbers (sum n no)");
        System.out.println("4. Prime Test (prime test)");
        System.out.print("Select an option: ");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                int factorialResult = factorial(choice);
                if (factorialResult != -1) {
                    System.out.println("Factorial: " + factorialResult);
                }
                break;
            case 2:
                fibonacci(choice);
                break;
            case 3:
                int sumResult = sumOfNumbers(choice);
                if (sumResult != -1) {
                    System.out.println("Sum of numbers: " + sumResult);
                }
                break;
            case 4:
                boolean isPrimeResult = isPrime(choice);
                System.out.println("Prime Test: " + isPrimeResult);
                break;
            default:
                System.out.println("Error: Invalid option selected.");
                break;
        }

        scanner.close();
    }
}
