package com.amrita.jpl.cys21066.EX;

class vehi {
    protected boolean run_status;

    public void start() {
        run_status = true;
        System.out.println("[Vehicle] started.");
    }

    public void stop() {
        run_status = false;
        System.out.println("[Vehicle] stopped.");
    }
}

class car extends Vehicle {
    private String modelName;
    private int year;
    private int numOfWheels;

    public car(String modelName, int year, int numOfWheels) {
        this.modelName = modelName;
        this.year = year;
        this.numOfWheels = numOfWheels;
        System.out.println("Car Instantiated with Parameter " + modelName + ", " + year + ", " + numOfWheels);
    }

    public void drive(int gearPosition) {
        if (run_status) {
            System.out.println("Driving the car in gear position: " + gearPosition);
        } else {
            System.out.println("Cannot drive. Start the car first.");
        }
    }
}

class bike extends Vehicle {
    private String brandName;
    private int year;
    private int numOfGears;

    public bike(String brandName, int year, int numOfGears) {
        this.brandName = brandName;
        this.year = year;
        this.numOfGears = numOfGears;
        System.out.println("Bike Instantiated with Parameter " + brandName + ", " + year + ", " + numOfGears);
    }

    public void pedal(int pedalSpeed) {
        if (run_status) {
            System.out.println("Pedaling the bike at speed: " + pedalSpeed);
        } else {
            System.out.println("Cannot pedal. Start the bike first.");
        }
    }
}

public class negateInheritance {
    public static void main(String[] args) {
        car car = new car("Jaguar XF", 2022, 4);
        car.drive(3);
        car.stop();

        bike bike = new bike("Giant", 2021, 18);
        bike.pedal(10);
        bike.stop();
    }
}
