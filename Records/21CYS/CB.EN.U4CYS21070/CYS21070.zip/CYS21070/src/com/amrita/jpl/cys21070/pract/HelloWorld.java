package com.amrita.jpl.cys21070.pract;
public class HelloWorld{ //Simple Hello World Program
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}